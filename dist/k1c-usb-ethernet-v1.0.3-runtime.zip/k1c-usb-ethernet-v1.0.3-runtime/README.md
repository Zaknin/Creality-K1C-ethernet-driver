# K1C USB Ethernet v1.0.3 runtime

Ready-to-install package for verified 2023 K1C Linux 4.4.94.
Check the release SHA256SUMS before installing, and keep Wi-Fi enabled.

Install: sh ./install.sh --enable-boot (only after stopping and
uninstalling an existing package-owned version).

Two RX options: drop_l2_8899=Y (default), rx_ipv4_only=N (default).
See FILTER-MODES.md for live toggles and restrictions.
