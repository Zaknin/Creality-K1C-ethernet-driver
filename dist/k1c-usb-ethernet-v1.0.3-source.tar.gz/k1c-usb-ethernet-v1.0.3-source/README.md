# K1C USB Ethernet v1.0.3 source

Source corresponding to v1.0.3 runtime CDC-NCM filter binary.
External compatible Ingenic K1C SDK/kernel/toolchain required.
No prebuilt modules, firmware, SDK or sysroot in this archive.
See docs/BUILD-FROM-SOURCE.md and docs/FILTER-MODES-v1.0.3.md.
